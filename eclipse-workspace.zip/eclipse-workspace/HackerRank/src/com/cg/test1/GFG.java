package com.cg.test1;

class Gfg { 
    public static void main(String args[]) 
    { 
        String s = "Gfg"; 
        s = s.concat("! is the best."); 
        System.out.println(s); 
    } 
} 