package com.cg.test1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

public class CamelCase {

	public static void main(String[] args) {
		
		String sb="sunaina is awesome girl";
        
		StringTokenizer st=new StringTokenizer(sb);
		List< String> li=new ArrayList< String>();
		
		
		
		List< String> res=new ArrayList< String>();
	    while(st.hasMoreTokens())
	     li.add(st.nextToken());
	    
	    char a1;
	    String first;
	    StringBuffer result =new StringBuffer();
	    for (String string : li) {
	    	
	    	a1= string.charAt(0);
            first=Character.toString(a1);
            res.add(string.replaceFirst(first, first.toUpperCase()));
 
		}
	    
	    
	    for (String string : res) 
	    	result.append(string+" ");
	    	
	    
	    System.out.print( "*"+result.toString().trim()+"*");
	   
		
	}
	
}
