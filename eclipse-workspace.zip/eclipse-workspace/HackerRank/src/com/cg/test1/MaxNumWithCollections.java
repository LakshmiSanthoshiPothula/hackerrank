//package com.cg.test1;
//
//public class MaxNumWithCollections {
//
//	public static void main(String[] args) {
//		String s[]= {"712" , "246", "365", "312"};
//		int res=maxNum(s);
//	    System.out.println(res);
//	}
//
//	public static int maxNum(String[] s) {
//		int m=s.length;
//		String a=s[0];
//		int res=0;
//		int n=a.length();
//		
//		char arr[][]=new char[m][n];
//		
//		for(int i=0;i<m;i++) {
//			for(int j=0;j<n;j++) {
//				
//				String s1=s[i];//246 i=1 j=0
//			
//				  arr[i][j]=(s1.charAt(j));
//				
//				
//				
//			}
//			System.out.println();	
//		}
//		
//		int max=maxElement(arr,m,n);
//		
//		System.out.println(max);
//		StringBuilder sb=new StringBuilder();
//		sb.append(s);
//
//		
//		return res;
//	}
//
//	public static int maxElement(int[][] arr, int m, int n) {
//		int max=0;
//		for(int i=0;i<m;i++) {
//			
//			for(int j=0;j<n;j++) {
//				if(max<arr[i][j]) {
//					max=arr[i][j];
//					
//				}
//				}
//			//sb.delete(, end);
//			
//			
//		}
//		
//		return max;
//	}
//
//
//}
