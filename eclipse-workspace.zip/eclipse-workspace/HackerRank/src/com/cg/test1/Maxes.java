package com.cg.test1;

import java.util.Scanner;

public class Maxes {


	public int[] maxesResult(int[]nums, int[]maxes) {
		int temp[]= new int[nums.length];
		int size=0;
		
		for(int i=0;i<nums.length;i++) {
			int s=0;
			for(int j=0;j<maxes.length;j++) {
			if(nums[i]<=maxes[j]) {
				s++;
				if(s==maxes.length) {
					size++;
					temp[i]=nums[i];
				}
			}
			}
		}
	
		   int result[] = new int[size];
		   for (int i=0; i < size; i++){
	            result[i] = temp[i];
	        }
	     
		 
		return result;
	} 

	public static void main(String[] args) {
	
Maxes obj=new Maxes();
	
		Scanner s= new Scanner(System.in);
		System.out.println("nums length");
		
		int n1= s.nextInt();
		
		int nums[]= new int[n1];
		System.out.println("nums array ");
		for(int i=0;i<nums.length;i++) {
			nums[i]=s.nextInt();
		}
		System.out.println("maxes length");
		
		int m1=s.nextInt();
		System.out.println("maxes array");
		int maxes[]= new int[m1];
		for(int i=0;i<maxes.length;i++) {
			maxes[i]=s.nextInt();
		}
		int result[]= new int[nums.length];
		result=obj.maxesResult(nums, maxes);
		for(int i=0;i<result.length;i++) {
		System.out.println(result[i]);
		}
		s.close();
		// TODO Auto-generated method stub

	}

}
