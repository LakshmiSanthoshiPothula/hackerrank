package com.cg.test1;

import java.util.Arrays;

public class Demo {

	public static void main(String[] args) {
		int[] a={5,6,2,1,9,4,3};
		Arrays.sort(a);
		for (int i : a) {
			System.out.print(i);	
		}
		

	}

}
