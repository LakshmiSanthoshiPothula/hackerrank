//package com.cg.practice;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//public class EvenSubArrayWithCollections {​​​​​​​​​​​​​​
//	    
//	    public static int evenSubArray (List<Integer> list,int k) {​​​​​​​
//	        
//	        List<Integer> nums=null;
//	        int count=0,oddcount;
//	        Set<List<Integer>> subArrays=new HashSet<>();
//	        
//	        
//	        for(int i=0;i<list.size();i++) {​​​​​​​
//	            nums=new ArrayList<Integer>();
//	            for(int j=i+1;j<=list.size();j++) {​​​​​​​
//	                nums=list.subList(i, j);
//	                subArrays.add(nums);
//	                //System.out.println(nums);
//	                
//	                oddcount=0;
//	                for(int n:nums) {​​​​​​​
//	                    if(n%2!=0)
//	                        oddcount++;
//	                }​​​​​​​
//	                if(oddcount<=k)
//	                    count++;
//	                
//	            }​​​​​​​
//	            
//	        
//	        }​​​​​​​
//	        
//	        
//	        
//	        return count;
//	    }​​​​​​​
//
//
//	    public static void main(String[] args) {​​​​​​​
//	        //List<Integer> list= Arrays.asList(1, 2, 3, 4);
//	        List<Integer> list= Arrays.asList(6, 3, 5, 8);
//	        int k=1;
//	        int count=evenSubArray(list,k);
//	        System.out.println("Count:" + count);
//
//
//	    }​​​​​​​
//
//
//	}​​​​​​​
//	 
//
//
//
//		Iterator<Character> distinctIterator=distinctList.iterator();
		
     //Creating a "Map" elements with each Distinct Character in the i/p string as Key
	//and their occurrence in the i/p string as Value(initialized to 0 first)
//		Map<Character, Integer> hm;
//	    Iterator<Map.Entry<Character, Integer>> hmIterator; 
//       



//        	 hm=new HashMap<Character, Integer>();
//     		  while(distinctIterator.hasNext())
//     		   hm.put(distinctIterator.next(),0);
//     		  hmIterator = hm.entrySet().iterator();
     		

//     	  for(Character c:subString)   
//           { 
//     		 while(hmIterator.hasNext()) {
//     			 
//     			Map.Entry<Character, Integer> entry = hmIterator.next(); 
//     			 
//     			 if(entry.getKey()==c) 
//     				 hm.put(c, entry.getValue()+1);    //
//     		}
//     		 
//           }
     	  