package com.cg.practice;

import java.util.Scanner;

public class Result {
    public static int consecutive(long num) {
    	int N=(int)num;
    	
    	 int a = 1,result=0,sum = 0;
    	   while (a < N){
             for (int i = a; i <= N; i++){
    	         sum = sum + i;
    	         if (sum == N){
    	        	 result++;
    	           }
    	       
    	         if (sum > N)
    	            break;
    	      }
    	     
    	      sum = 0;
    	      a++;
    	   }
    	return result ;
    	 }
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
	    System.out.println("Enter long value");
	    long num=sc.nextLong();
	    long result=consecutive(num);
	    System.out.println("**Possible Sequences**");
	    System.out.println(result);

	    sc.close();
	}

}
