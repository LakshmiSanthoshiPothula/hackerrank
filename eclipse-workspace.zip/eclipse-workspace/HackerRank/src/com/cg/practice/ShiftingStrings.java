package com.cg.practice;

import java.util.Scanner;

public class ShiftingStrings {
	
	public static String getShiftedString(String str, int left, int right) {
		
          String result =leftShift(str, left);
		  result = rightShift(result, right);
		
		
		return result;
	}
	public static String leftShift(String str, int d)
    {
            String ans = str.substring(d) + str.substring(0, d);
            return ans;
    }
 
    
    public static String rightShift(String str, int d)
    {
            return leftShift(str, str.length() - d);
    }
 
	
public static void main(String[] args) {
	String str;
	int left, right;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter String");
	str=sc.nextLine();
	System.out.println("Enter left shifts");
	left=sc.nextInt();
	System.out.println("Enter rights shifts");
	right=sc.nextInt();
	String result= getShiftedString(str,left,right);
	System.out.println("**Shifted String***");
	System.out.println(result);
	sc.close();
	}

	

}
