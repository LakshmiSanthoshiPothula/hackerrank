package com.cg.practice;


interface Company {
void assignSalaries(int[] salaries);
void averageSalary();
void maxSalary();
void minSalary();
}

/* model output for cut and paste
Incomes of ____ credited
Average salary of ____ is ____
Maximum salary amongst ____ is ____
Minimum salary amongst ____ is ____
*/


public class Solution {
public static void main(String args[] ) throws Exception {
//Scanner sc = new Scanner(System.in);
//String[] count = sc.nextLine().split(" ");


//for (int i=0; i < count.length; i++) {
//incomeEngineers[i] = Integer.parseInt(count[i]);
//}
	
	  int[] incomeEngineers ={6848,9329,9984,5543,7985};
	EngineerFirm e = new EngineerFirm(incomeEngineers.length);
  
e.assignSalaries(incomeEngineers);
e.averageSalary();
e.maxSalary();
e.minSalary();


}
}