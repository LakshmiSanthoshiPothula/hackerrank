package com.cg.practice;

import java.util.Scanner;

public class Length {
	
	static String mul(String a, int n) {

        String temp = new String(a);

        for (int i = 0; i < n; i++)
            temp= temp.concat(a);

        return temp;

		
//		 String temp = new String("");
//
//	        for (int i = 0; i < n; i++)
//
//	            temp += a;
//
//	        return temp;
    }

	
	static String strcpy(String s, int n) {

        String temp = new String("");

        for (int i = 0; i < n; i++) {

            temp += s.charAt(i);
     

        }

        return temp;

    }

    // this is required function

    static int isDivisible(String s, String t) {

        int lens = s.length();

        int lent = t.length();

        // if strings can't be devided

        if (!(lens % lent==0))
        	return -1;

 

        // devisor

        int div = lens / lent;
     
        

        String temp = new String("");

        // create t*div string

        for (int i = 0; i < div; i++)

        temp += t;

        // if t*div == s

        if (temp.equals(s)) {

            for (int i = 1; i <= lent; i++) {

                div = lent / i;

                if (lent % i == 0) {

                    temp = strcpy(t, i);
                    System.out.println(temp);

                    if (mul(temp, div).equals(t)) 
                            return i;

                    

                }

            }

        }

        return -1;

    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter s: ");

        String s = sc.nextLine();

        

        System.out.print("Enter t: ");

        String t = sc.nextLine();

        int min_length = isDivisible(s, t);

        if (min_length == -1)

            System.out.println("s is not divisible by t");

        else

            System.out.println("Minimum length string: " + min_length);
        
        sc.close();

	}

}
