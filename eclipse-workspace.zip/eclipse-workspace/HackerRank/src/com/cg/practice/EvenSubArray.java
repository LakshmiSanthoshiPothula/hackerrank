 package com.cg.practice;

import java.util.Scanner;

public class EvenSubArray {
	

	public static int evenSubarray(int numbers[],int n, int k) {
		
		int result=0;
		for (int i=0; i <n; i++) 
		{
			for (int j=i; j<n; j++)   
				
				
			{  
				int odd=0;
	           for (int l=i; l<=j; l++) 
				{    
					 if(numbers[l]%2!=0)
						 odd++;
			    }
	        
			  if(odd<=k)
				  result++;
			}
		}
		
		return result;
	}
		
	

	public static void main(String[] args) {
		
		Scanner sc=new Scanner (System.in);
	
		
		System.out.println("Enter size of the array");
		int n= sc.nextInt();
        int numbers[]=new int[n];
        
        System.out.println("Enter array elements");
        
        for (int i=0;i<numbers.length;i++) {

        	numbers[i]=sc.nextInt();
        
        }
        System.out.println("Enter no of odd numbers allowed"); 
        int k= sc.nextInt();
        int result= evenSubarray(numbers,n,k);
        
        System.out.println("Distinct Subarrays Formed with atmost "+k+ " odd elements: "+result);
	sc.close();
	}

}