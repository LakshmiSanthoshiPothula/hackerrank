package com.cg.practice;

import java.util.Arrays;


public class AnagramDiff{
	
	



	public static int[] getMinimumDifference(String a[], String b[]) {
		
		int[] result= new int[a.length];
		int i;
		for(i=0;i<a.length;i++) {
			
			
			result[i]=anagramDifference(a[i],b[i]);
		}
		return result;
		}

	private static int anagramDifference(String s1, String s2) {
	
	    char[] a1 = s1.toCharArray();
		char[] a2 = s2.toCharArray();
		int i,j,difference=a1.length;
		Arrays.sort(a1);
		Arrays.sort(a2);
		
		
		
		
		// 

		if(s1.length()!=s2.length())
        return -1;

		else if(Arrays.equals(a1, a2)) 
		    	   return 0;
		
		else {
			for(i=0; i<a1.length;i++) {             
				
				for(j=0; j<a2.length;j++) {
				
					
					if(a1[i]==a2[j]) {
						
						a2[j]='0';
						difference--;
				        break;
				}
				
         	}
			}
			
			return difference;
			
	}
		
    
	}
		
			

	public static void main(String[] args) {
	      
	 String a[]= {"a", "jk", "abb","mn", "abc"};
     String b[]= {"bb", "kj", "bbc", "op", "def"};
	 int result[]=getMinimumDifference(a,b);
	 System.out.println("**RESULT**");
	 for(int i:result)
	 System.out.println(i);

	}
	
}
