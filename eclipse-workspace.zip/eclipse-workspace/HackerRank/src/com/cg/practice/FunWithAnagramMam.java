package com.cg.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class FunWithAnagramMam {
	   public static String sortString(String s) {
	        char[] chs= s.toCharArray();
	        Arrays.sort(chs);
	        String str=new String(chs).trim();
	        return str;
	    }
	    
	    public static List<String> funWithAnagram(List<String> list) {
	        
	        List<String> tempList=new ArrayList<String>();
	        for(String s:list)
	            tempList.add(s);
	        
	       for(String str:tempList) {
	           int count=0;
	           Iterator<String> iterator=list.iterator();
	           while(iterator.hasNext()) {
	              
	               if(sortString(str).equals(sortString(iterator.next()))) 
	                count++;
	               
	               if(count>1) 
	               iterator.remove();
	        }
	       }
	       Collections.sort(list);
	       return list;
	    }

	 

	 

	 

	    public static void main(String[] args) {
	   //ArrayList<String> list= new ArrayList<String>(Arrays.asList("code","aaagmnrs","anagrams","doce"));
	    // List<String> list=Arrays.asList("poke","pkoe","okpe","ekop");
	        List<String> list=new ArrayList<String>();
	        list.add("poke");
	        list.add("pkoe");
	        list.add("okpe");
	        list.add("ekop");
	        list.add("ekop");
	        list.add("ekop");
	        list.add("ekop");
	        
	        List<String> result=funWithAnagram(list);
	         System.out.println("**RESULT**");
	         for(String i:result)
	         System.out.println(i);
	        

	 

	    }

}
