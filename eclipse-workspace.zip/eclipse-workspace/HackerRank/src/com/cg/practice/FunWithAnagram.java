package com.cg.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
 
public class FunWithAnagram {
	
	public static List<String> funWithAnagram(ArrayList<String> list) {
		
		
		for(int i=0;i<list.size();i++) {
			for(int j=i+1;j<list.size();j++) {
				char[] a1 = list.get(i).toCharArray();
				char[] a2 = list.get(j).toCharArray();
			
				Arrays.sort(a1);
				Arrays.sort(a2);
				
				if(Arrays.equals(a1, a2)) 
				list.remove(list.get(j));
				}
		}
		
		List<String> result=list.stream().sorted().collect(Collectors.toList());
		
		
		return result;
	}

	public static void main(String[] args) {
   //ArrayList<String> list= new ArrayList<String>(Arrays.asList("code","aaagmnrs","anagrams","doce"));
 ArrayList<String> list= new ArrayList<String>(Arrays.asList("poke","pkoe","okpe","ekop"));
 	
 	
 	
		List<String> result=funWithAnagram(list);
		 System.out.println("**RESULT**");
		 for(String i:result)
		 System.out.println(i);
	    

	}

	
}
