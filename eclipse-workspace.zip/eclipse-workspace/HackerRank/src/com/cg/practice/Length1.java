package com.cg.practice;

public class Length1 {

	public static void main(String[] args) {
		
	}

}
