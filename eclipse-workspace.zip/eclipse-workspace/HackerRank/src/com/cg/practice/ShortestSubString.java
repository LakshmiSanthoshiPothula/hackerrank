package com.cg.practice;


import java.util.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class ShortestSubString {
	
	
	public static String shortestSubstring(String str) {
		
		//conversion of input string to list of characters 
		List<Character> listInput = new ArrayList<>(); 
	    for (char ch : str.toCharArray())
	    	listInput.add(ch); 
	    
        //creating a "Set" of all possible substrings from input string
	    List<Character> subs=null;
		Set<List<Character>> subStrings=new HashSet<>();
		
		for(int i=0; i<=listInput.size();i++) {
		for(int j=i+1; j<=listInput.size();j++) {
			 subs= new ArrayList<Character>();
			 subs= listInput.subList(i,j);
			 subStrings.add(subs);
			 }
		}

		
		
		
		
		
		Iterator<List<Character>> setIterator=subStrings.iterator();
		
		
		//creating a "List" of distinct Characters present in the input string 
		List<Character> distinctList=  listInput.stream().distinct().collect(Collectors.toList());
		Iterator<Character> distinctIterator=distinctList.iterator();
		
     //Creating a "Map" elements with each Distinct Character in the i/p string as Key
	//and their occurance in the i/p string as Value(initialized to 0 first)
		Map<Character, Integer> hm;
	    Iterator<Map.Entry<Character, Integer>> hmIterator; 
        
        //"resultLength" is initialized to higher first
        List<Character> subString;
        String distinctString=distinctList.toString().trim(), resultString = null;
        int resultLength=999;
        
        //iterating a 
        while(setIterator.hasNext()) {
        	
        	 hm=new HashMap<Character, Integer>();
     		  while(distinctIterator.hasNext())
     		   hm.put(distinctIterator.next(),0);
     		  hmIterator = hm.entrySet().iterator();
     		
          subString=setIterator.next();
     	  for(Character c:subString)   
           { 
     		 while(hmIterator.hasNext()) {
     			 
     			Map.Entry<Character, Integer> entry = hmIterator.next(); 
     			 
     			 if(entry.getKey()==c) 
     				 hm.put(c, entry.getValue()+1);
     		}
     		 
           }
     	  
           String s1=subString.toString().trim();
     	  
     	  if(subString.size()<resultLength && isContainsAllChars(s1,distinctString) ) {
     		  
     		  resultLength=subString.size();
     		 resultString=subString.toString();
     		 
     		 }
     	 }
        
    return resultString;
	}
	
	//Checks if current substring contains all distinct Character that are present in the i/p string
	private static boolean isContainsAllChars(String s1, String distinctString) {
	    char[] a1 = s1.toCharArray();
		char[] a2 = distinctString.toCharArray();
	
		Arrays.sort(a1);
		Arrays.sort(a2);

		if(s1.length()!=distinctString.length()||!(Arrays.equals(a1, a2)))
        return false;
		else
		return true;
		
		
	}


public static void main(String[] args) {
		String str;
	    Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		
		
		
		str=sc.nextLine();
		String result= shortestSubstring(str);
		
		
		System.out.println("**Shortest SubString***");
		System.out.println(result);
		sc.close();
	

}

}