package com.cg.practice;



public class EngineerFirm implements Company {

	
	 int[] salaries;
	 public EngineerFirm(int l) {
		salaries =new int[l];
		for(int i=0;i<l;i++) {
			salaries[i]=0;
		}
		
	}

	@Override
	public void assignSalaries(int[] emp) {
		for(int i=0;i<salaries.length;i++) {
			salaries[i]=emp[i];
		}
		
		System.out.println("Incomes of engineers credited");

	}

	@Override
	public void averageSalary() {
		
		
		
		
		double sum=0;
		for(int i=0;i<salaries.length;i++) {
			sum+=salaries[i];
		}

		
		double avg=(sum/(salaries.length));
		//avg=Math.ceil(avg);
		
		
		System.out.format("Average salary of engineer is %.5f",avg);
		System.out.println();
		
	}

	@Override
	public void maxSalary() {
		float max=0;
		for(int i=0;i<salaries.length;i++) {
			if(max<salaries[i])
				max=salaries[i];
		}
		
		System.out.format("Maximum salary amongst engineer is %.5f",max);
		System.out.println();
	}

	@Override
	public void minSalary() {
		double min=Double.MAX_VALUE;
		System.out.println(min);
		for(int i=0;i<salaries.length;i++) {
			if(min>salaries[i])
				min=salaries[i];
		}
		
		System.out.format("Minimum salary amongst engineer is %.0f",min);
	}

}
