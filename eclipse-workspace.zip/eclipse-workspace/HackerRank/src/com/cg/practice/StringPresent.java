package com.cg.practice;

import java.util.Scanner;


public class StringPresent{


public static String kmp(String s1,String s2){
for(int i=0;i<=s1.length();i++){
for(int j=i+1;j<=s1.length();j++){
String f= s1.substring(i,j);

if(f.equals(s2))
return("YES");
}
            }


return("NO");
}
public static void main(String[] args) {
Scanner sc= new Scanner(System.in);
System.out.println("enter n");

int n = Integer.parseInt(sc.nextLine());
String s1,s2;
String[] res=new String[n];

for(int i=0;i<n;i++){
	

	System.out.println("Enter s1:");	

s1=sc.nextLine();

System.out.println("Enter s2:");
s2=sc.nextLine();

 res[i]= kmp(s1,s2);



}
for(int i=0;i<n;i++) {
System.out.println(res[i]);
}

sc.close();
System.exit(0);
}

}

