package objectclassfunctions;

public class Complex1 {
	private double re, im; 
	  public Complex1(double re, double im) { 
			this.re = re; 
			this.im = im; }

}
