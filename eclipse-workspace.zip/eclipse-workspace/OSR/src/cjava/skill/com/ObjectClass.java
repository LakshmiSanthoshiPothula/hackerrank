package cjava.skill.com;

public class ObjectClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ObjectClass o= new ObjectClass();
		System.out.println(o);
		System.out.println(o.toString());

	}

}
