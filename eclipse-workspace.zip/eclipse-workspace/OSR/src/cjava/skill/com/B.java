package cjava.skill.com;

public class B {

}
